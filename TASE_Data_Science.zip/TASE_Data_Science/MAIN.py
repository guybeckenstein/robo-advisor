#!/usr/bin/python
# -*- coding: utf-8 -*-
import json
import manageData
import User as User


######################################################################################
# set manually
stocksSymbols = [  # TODO -NEW FEATURES- creates features to scan good stocks and indexes and fit them to the portfolio
    "TA35.TA",
    "TA90.TA",
    601,
    602,
    700,
    701,
    702,
    'SPY',
    'QQQ',
    'rut',
    'IEI',
    'LQD',
    'Gsg',
    'GLD',
    'OIL'
    ]
numOfYearsHistory = 10

######################################################################################
manageData.mainMenu()
selection = int(input("Enter your selection: "))
manageData.selectedMenuOptValid(selection, 1, 5)
exitLoopOperation = 5

while selection != exitLoopOperation:

    if selection == 1:
        name = manageData.getName()
        user = manageData.createsNewUser(name, stocksSymbols, numOfYearsHistory)
        #plot results
        manageData.plotUserPortfolio(user)

    elif selection == 2: #TODO GET USER FROM LIST IN DJANGO PROJECT
        # update exist user data using model markovich or gini
        name = manageData.getName()
        selectedUser = manageData.getUserFromDB(name)
        manageData.refreshUserData(selectedUser)# TODO - FIX

    elif selection == 3: # TODO GET USER FROM LIST IN DJANGO PROJECT
        # plot user portfolio's data
        name = manageData.getName()
        selectedUser = manageData.getUserFromDB(name)
        if selectedUser is not None:
            manageData.plotUserPortfolio(selectedUser)



    elif selection == 4:
        manageData.expertMenu()
        # clear screen - TODO
        selection = int(input("Enter your selection: "))
        manageData.selectedMenuOptValid(selection, 1, 5)
        while selection != exitLoopOperation:
            if selection == 1:
                # forcast specific stock using machine learning
                stockName = name = manageData.getName()
                numOfYearsHistory = manageData.getNumOfYearsHistory()
                manageData.forcastSpecificStock(str(stockName), 0, numOfYearsHistory)
            elif selection == 2:
                # plotbb_strategy_stock for specific stock
                stockName = name = manageData.getName()
                numOfYearsHistory = manageData.getNumOfYearsHistory()
                staringDate, todayDate = manageData.getfromAndToDate(numOfYearsHistory)
                manageData.plotbb_strategy_stock(str(stockName), staringDate, todayDate)
            elif selection == 3:
                # TODO- IN PROGRESS
                # add history of index's data from taske(json file)
                indexid = 143
                manageData.createJsonDataFromTase(143, "History" + str(indexid))
            elif selection == 4:
                # TODO- IN PROGRESS
                manageData.scanGoodStocks()
            else:
                break
            manageData.expertMenu()
            selection = int(input("Enter your selection: "))
            manageData.selectedMenuOptValid(selection, 1, 5)
        else:
            break
    manageData.mainMenu()
    selection = int(input("Enter your selection: "))
    manageData.selectedMenuOptValid(selection, 1, 5)

######################################################################################
