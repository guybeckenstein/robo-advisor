import http.client
import json
import codecs
import re
import requests
import base64
import datetime
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import yfinance as yf
import seaborn as sns
import setting
import Portfolio as Portfolio
import User as User
import ta


# manage users data

def createsNewUser(name, stocksSymbols, numOfYearsHistory):

    sectorsData = getJsonData("DB/sectors")
    levelOfRisk = 1

    # GET BASIC DATA FROM TERMINAL- TODO- get the data from site-form
    investmentAmount, machineLearningOpt, modelOption = getUserBasicDataFromForm()
    newPortfolio = Portfolio.Portfolio(1, investmentAmount, stocksSymbols, sectorsData, modelOption, machineLearningOpt)

    # get data from api and convert it to tables
    (closingPricesTable, pctChangeTable) = \
        convertDataToTables(
            stocksSymbols,
            setting.record_percentage_to_predict,
            numOfYearsHistory,
            machineLearningOpt,
        )

    # use models to find the best portfolios
    if modelOption == 1:
        # use markovich model to find the best portfolios

        df, max_vols, threeBestPortfolosList, weighted_low,\
        weighted_medium, weighted_high = \
            markovichModel(setting.Num_porSimulation, pctChangeTable, stocksSymbols)
    else:
        # use gini model to find the best portfolios - alternative to markovich - TODO
        print("TODO")

    # find the level of risk according to the user's choice
    levelOfRisk = getDataFromForm(pctChangeTable, threeBestPortfolosList, newPortfolio, weighted_low, weighted_medium, weighted_high)
    newPortfolio.updateLevelOfRisk(levelOfRisk)

    # build the portfolio according to the level of risk
    selectedPortfolio = threeBestPortfolosList[levelOfRisk-1]
    newPortfolio.updateStocksData(closingPricesTable, pctChangeTable,
        selectedPortfolio.iloc[0][3:],
        selectedPortfolio.iloc[0][0],
        selectedPortfolio.iloc[0][1],
        selectedPortfolio.iloc[0][2]
    )
    user = User.User(name, newPortfolio)
    user.updateJsonFile("DB/users")

    return user


def getUserFromDB(userName):
    jsonData = getJsonData(setting.usersJsonName)
    if userName not in jsonData['usersList']:
        print("User not found")
        return None
    userData = jsonData['usersList'][userName][0]
    startingInvestmentAmount = userData['startingInvestmentAmount']
    machineLearningOpt = userData['machineLearningOpt']
    selectedModel = userData['selectedModel']
    levelOfRisk = userData['levelOfRisk']
    stocksSymbols = userData['stocksSymbols']
    stocksWeights = userData['stocksWeights']
    annualReturns = userData['annualReturns']
    annualVolatility = userData['annualVolatility']
    annualSharpe = userData['annualSharpe']

    #TODO - if each user has different sectors make sector data using sectorsNames and sectorsWeights
    sectorsNames = userData['sectorsNames']
    sectorsWeights = userData['sectorsWeights']
    sectorsData = getJsonData("DB/sectors")# universal from file

    # get data from api and convert it to tables
    closingPricesTable, pctChangeTable = convertDataToTables(stocksSymbols, setting.record_percentage_to_predict,
                                                             setting.numOfYearsHistory, machineLearningOpt)

    userPortfolio = Portfolio.Portfolio(levelOfRisk, startingInvestmentAmount, stocksSymbols, sectorsData,
                                        selectedModel, machineLearningOpt)


    weighted_sum = np.dot(stocksWeights, pctChangeTable.T)
    pctChangeTable["weighted_sum_"+str(levelOfRisk)] = weighted_sum
    pctChangeTable["yield_"+str(levelOfRisk)] = weighted_sum
    yield_low = makesYieldColumn(pctChangeTable["yield_"+str(levelOfRisk)], weighted_sum, startingInvestmentAmount)
    userPortfolio.updateStocksData(closingPricesTable, pctChangeTable, stocksWeights, annualReturns, annualVolatility, annualSharpe)

    user = User.User(userName, userPortfolio)

    return user


def getAllUsers():# TODO
    jsonData = getJsonData(setting.usersJsonName)
    numOfUser = len(jsonData['usersList'])
    usersData = jsonData['usersList']
    _usersList = []*numOfUser
    for i, userData in usersData.items():
           userI = getUserFromDB(i)
           _usersList.append(userI)

    return _usersList


def refreshUserData(user):

    portfolio = user.getPortfolio()
    pctChangeTable = portfolio.getPctChangeTable()
    returns_daily = pctChangeTable
    weights = portfolio.getStocksWeights()
    returns_annual = ((1 + returns_daily.mean()) ** 254) - 1
    cov_daily = returns_daily.cov()
    cov_annual = cov_daily * 254
    returns = np.dot(weights, returns_annual)
    volatility = np.sqrt(np.dot(weights, np.dot(cov_annual, weights)))
    sharpe = returns / volatility
    # find the level of risk according to the user's choice
    # build the portfolio according to the level of risk
    user.portfolio.updateStocksData(portfolio.getclosingPricesTable(), pctChangeTable,
        weights,
        returns_annual,
        volatility,
        sharpe
    )


def markovichModel(Num_porSimulation, pctChangeTable, stocksSymbols):

    stocksNames = []
    for symbol in stocksSymbols:
        if type(symbol) == int:
            stocksNames.append(str(symbol))
        else:
            stocksNames.append(symbol)

    returns_daily = pctChangeTable
    returns_annual = ((1 + returns_daily.mean()) ** 254) - 1
    cov_daily = returns_daily.cov()
    cov_annual = cov_daily * 254

    # empty lists to store returns, volatility and weights of imiginary portfolios
    port_returns = []
    port_volatility = []
    sharpe_ratio = []
    stock_weights = []

    # set the number of combinations for imaginary portfolios
    num_assets = len(stocksSymbols)
    num_portfolios = Num_porSimulation

    # set random seed for reproduction's sake
    np.random.seed(101)

    # populate the empty lists with each portfolios returns,risk and weights
    for single_portfolio in range(num_portfolios):
        weights = np.random.random(num_assets)
        weights /= np.sum(weights)
        returns = np.dot(weights, returns_annual)
        volatility = np.sqrt(np.dot(weights.T, np.dot(cov_annual, weights)))
        sharpe = returns / volatility
        sharpe_ratio.append(sharpe)
        port_returns.append(returns * 100)
        port_volatility.append(volatility * 100)
        stock_weights.append(weights)

    # a dictionary for Returns and Risk values of each portfolio
    portfolio = {
        "Returns": port_returns,
        "Volatility": port_volatility,
        "Sharpe Ratio": sharpe_ratio,
    }

    # extend original dictionary to accomodate each ticker and weight in the portfolio
    for counter, symbol in enumerate(stocksNames):
        portfolio[symbol + " Weight"] = [Weight[counter] for Weight in stock_weights]

    # make a nice dataframe of the extended dictionary
    df = pd.DataFrame(portfolio)

    # get better labels for desired arrangement of columns
    column_order = ["Returns", "Volatility", "Sharpe Ratio"] + [
        stock + " Weight" for stock in stocksNames
    ]
    # reorder dataframe columns
    df = df[column_order]

    min_variance_port = df.loc[df["Volatility"] == df["Volatility"].min()]  # low risk
    sharpe_portfolio = df.loc[df["Sharpe Ratio"] == df["Sharpe Ratio"].max()]  # medium risk
    max_returns = df.loc[df["Returns"] == df["Returns"].max()]  # high risk
    max_vols = df.loc[df["Volatility"] == df["Volatility"].max()]

    ThreePortfoliosList = [min_variance_port, sharpe_portfolio, max_returns]

    # get 3 portfolios weights
    weighted_low = np.dot(min_variance_port.iloc[0][3:], pctChangeTable.T)
    weighted_medium = np.dot(sharpe_portfolio.iloc[0][3:], pctChangeTable.T)
    weighted_high = np.dot(max_returns.iloc[0][3:], pctChangeTable.T)

    return df, max_vols, ThreePortfoliosList, weighted_low, weighted_medium, weighted_high


def convertDataToTables(stocksNames, record_percentage_to_predict,
                        numOfYearsHistory, machineLearningOpt):
    frame = {}
    yf.pdr_override()
    start_date, end_date = getfromAndToDate(numOfYearsHistory)

    for i, stock in enumerate(stocksNames):
        if type(stock) == int:
            IsraeliStockData = getIsraeliIndexesData("get_past_10_years_history", stock)
            df = pd.DataFrame(IsraeliStockData["indexEndOfDay"]["result"])
            df["tradeDate"] = pd.to_datetime(df["tradeDate"])
            df.set_index("tradeDate", inplace=True)
            if machineLearningOpt == 1:
                DF, price = price_forecast(df, record_percentage_to_predict, 1)  # 1-Data From Tase
            else:
                price = df[["closingIndexPrice"]]
            frame[stocksNames[i]] = price
        else:
            df = yf.download(stock, start=start_date, end=end_date)
            if machineLearningOpt == 1:
                DF, price = price_forecast(df, record_percentage_to_predict, 0)  # 0 -Data from Yahoo
            else:
                price = df[["Adj Close"]]
            frame[stock] = price

    closingPricesTable = pd.concat(frame.values(), axis=1, keys=frame.keys())
    pctChangeTable = closingPricesTable.pct_change()
    pctChangeTable.fillna(0, inplace=True)

    return closingPricesTable, pctChangeTable

def price_forecast(df, record_percentage_to_predict, isDataFromTase):

    if isDataFromTase == 1:
        df["HL_PCT"] = (df["high"] - df["low"]) / df["low"] * 100.0
        df["PCT_change"] = (
            (df["closingIndexPrice"] - df["indexOpeningPrice"])
            / df["indexOpeningPrice"]
            * 100.0
        )

        df = df[["closingIndexPrice", "HL_PCT", "PCT_change"]]

        forecast_col = "closingIndexPrice"

    else:
        df["HL_PCT"] = (df["High"] - df["Low"]) / df["Low"] * 100.0
        df["PCT_change"] = (df["Close"] - df["Open"]) / df["Open"] * 100.0

        df = df[["Adj Close", "HL_PCT", "PCT_change", "Volume"]]

        forecast_col = "Adj Close"

    df.fillna(value=-99999, inplace=True)
    forecast_out = int(math.ceil(record_percentage_to_predict * len(df)))
    df["label"] = df[forecast_col].shift(-forecast_out)
    print(df.head())

    X = np.array(df.drop(["label"], 1))
    X = preprocessing.scale(X)
    X_lately = X[-forecast_out:]
    X = X[:-forecast_out]
    df.dropna(inplace=True)

    y = np.array(df["label"])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=record_percentage_to_predict
    )
    clf = LinearRegression()
    clf.fit(X_train, y_train)
    confidence = clf.score(X_test, y_test)
    print(confidence)
    forecast_set = clf.predict(X_lately)
    df["Forecast"] = np.nan

    last_date = df.iloc[-1].name
    last_unix = last_date.timestamp()
    one_day = 86400
    next_unix = last_unix + one_day

    for i in forecast_set:
        next_date = datetime.datetime.fromtimestamp(next_unix)
        next_unix += 86400
        df.loc[next_date] = [np.nan for _ in range(len(df.columns) - 1)] + [i]

    col = df["Forecast"]
    col = col.dropna()
    return df, col


def forcastSpecificStock(stock, isDataComeFromTase, numOfYearsHistory):
    if isDataComeFromTase:

        df = pd.DataFrame(stock["indexEndOfDay"]["result"])
        df["tradeDate"] = pd.to_datetime(df["tradeDate"])
        df.set_index("tradeDate", inplace=True)
        df, col = price_forecast(df, setting.record_percentage_to_predict, 1)
        plotpriceForcast(stock, df, 1)

    else:
        yf.pdr_override()
        start_date, end_date = getfromAndToDate(numOfYearsHistory)
        df = yf.download(stock, start=start_date, end=end_date)
        df, col = price_forecast(df, setting.record_percentage_to_predict, 0)
        plotpriceForcast(stock, df, 0)


def makesYieldColumn(_yield, weighted_sum_column, investment):
    _yield.iloc[0] = investment
    for i in range(1, weighted_sum_column.size):
        change = weighted_sum_column.item(i) + 1
        lastValue = _yield.iloc[i - 1]
        newValue = lastValue * change
        _yield.iloc[i] = newValue
    return _yield

# plot graph

def plotUserPortfolio(user):

    portfolio = user.getPortfolio()
    plt = user.plotPortfolioComponent()
    plt.show()
    plt = user.plotInvestmentPortfolioYield()
    plt.show()


def plotMarkovichPortfolioGraph(df, max_vols,ThreePortfoliosList, newPortfolio):

    min_variance_port = ThreePortfoliosList[0]
    sharpe_portfolio = ThreePortfoliosList[1]
    max_returns = ThreePortfoliosList[2]

    # plot frontier, max sharpe & min Volatility values with a scatterplot
    figSize_X = 10
    figSize_Y = 8
    figSize = (figSize_X, figSize_Y)
    plt.style.use("seaborn-dark")
    df.plot.scatter(
        x="Volatility",
        y="Returns",
        c="Sharpe Ratio",
        cmap="RdYlGn",
        edgecolors="black",
        figsize=figSize,
        grid=True,
    )
    plt.scatter(
        x=sharpe_portfolio["Volatility"],
        y=sharpe_portfolio["Returns"],
        c="green",
        marker="D",
        s=200,
    )
    plt.scatter(
        x=min_variance_port["Volatility"],
        y=min_variance_port["Returns"],
        c="orange",
        marker="D",
        s=200,
    )
    plt.scatter(
        x=max_vols["Volatility"], y=max_returns["Returns"], c="red", marker="D", s=200
    )
    plt.style.use("seaborn-dark")

    plt.xlabel("Volatility (Std. Deviation) Percentage %")
    plt.ylabel("Expected Returns Percentage %")
    plt.title("Efficient Frontier")
    plt.subplots_adjust(bottom=0.4)

    # ------------------ Pritning 3 optimal Protfolios -----------------------
    # Setting max_X, max_Y to act as relative border for window size
    sectorsNames = newPortfolio.getSectorsNames()
    lowWeight = min_variance_port.iloc[0][3:]
    mediumWeight = sharpe_portfolio.iloc[0][3:]
    highWeight = max_returns.iloc[0][3:]
    stocksStrHigh = ""
    stocksStrLow = ""
    stocksStrMedium = ""
    highSectorsWeight = newPortfolio.returnSectorsWeightsAccordingToStocksWeights(highWeight)
    lowSectorsWeight = newPortfolio.returnSectorsWeightsAccordingToStocksWeights(lowWeight)
    mediumSectorsWeight = newPortfolio.returnSectorsWeightsAccordingToStocksWeights(mediumWeight)

    # stocksStrHigh
    for i in range(len(sectorsNames)):
        weight = highSectorsWeight[i] * 100
        stocksStrHigh += sectorsNames[i] + "(" + str("{:.2f}".format(weight)) + "%),\n "
    # stocksStrMedium
    for i in range(len(sectorsNames)):
        weight = mediumSectorsWeight[i] * 100
        stocksStrMedium += sectorsNames[i] + "(" + str("{:.2f}".format(weight)) + "%),\n "
    # stocksStrLow
    for i in range(len(sectorsNames)):
        weight = lowSectorsWeight[i] * 100
        stocksStrLow += sectorsNames[i] + "(" + str("{:.2f}".format(weight)) + "%),\n "

    with pd.option_context("display.float_format", "%{:,.2f}".format):
        plt.figtext(
            0.2,
            0.15,
            "Max returns Porfolio: \n"
            + "Annual returns: " + str(round(max_returns.iloc[0][0], 2)) + "%\n"
            + "Annual volatility: " + str(round(max_returns.iloc[0][1], 2)) + "%\n"
            + "Annual max loss: " + str(round(max_returns.iloc[0][0] - 1.65*max_returns.iloc[0][1], 2)) + "%\n"
            + "Sharpe Ratio: " + str(round(max_returns.iloc[0][2], 2)) + "\n"
            + stocksStrHigh,
            bbox=dict(facecolor="red", alpha=0.5),
            fontsize=11,
            style="oblique",
            ha="center",
            va="center",
            fontname="Arial",
            wrap=True,
        )
        plt.figtext(
            0.45,
            0.15,
            "Safest Portfolio: \n"
            + "Annual returns: " + str(round(min_variance_port.iloc[0][0], 2)) + "%\n"
            + "Volatility: " + str(round(min_variance_port.iloc[0][1], 2)) + "%\n"
            + "Max loss: " + str(round(min_variance_port.iloc[0][0] - 1.65 * min_variance_port.iloc[0][1], 2)) + "%\n"
            + "Sharpe Ratio: " + str(round(min_variance_port.iloc[0][2], 2)) + "\n"
            + stocksStrLow,
            bbox=dict(facecolor="yellow", alpha=0.5),
            fontsize=11,
            style="oblique",
            ha="center",
            va="center",
            fontname="Arial",
            wrap=True,
        )
        plt.figtext(
            0.7,
            0.15,
            "Sharpe  Portfolio: \n"
            + "Annual returns: " + str(round(sharpe_portfolio.iloc[0][0], 2)) + "%\n"
            + "Volatility: " + str(round(sharpe_portfolio.iloc[0][1], 2)) + "%\n"
            + "Max loss: " + str(round(sharpe_portfolio.iloc[0][0] - 1.65 * sharpe_portfolio.iloc[0][1], 2)) + "%\n"
            + "Sharpe Ratio: " + str(round(sharpe_portfolio.iloc[0][2], 2)) + "\n"
            + stocksStrMedium,
            bbox=dict(facecolor="green", alpha=0.5),
            fontsize=11,
            style="oblique",
            ha="center",
            va="center",
            fontname="Arial",
            wrap=True,
        )
    plt.show()


def plotThreePortfoliosGraph(ThreePortfoliosList, newPortfolio, pctChangeTable):
    min_variance_port = ThreePortfoliosList[0]
    sharpe_portfolio = ThreePortfoliosList[1]
    max_returns = ThreePortfoliosList[2]

    # plot frontier, max sharpe & min Volatility values with a scatterplot
    figSize_X = 10
    figSize_Y = 8
    figSize = (figSize_X, figSize_Y)
    plt.style.use("seaborn-dark")
    plt.xlabel("Datte")
    plt.ylabel("Expected Returns")
    plt.title("3 best portfolios")

    pctChangeTable['yield_1'].plot(figsize=figSize, grid=True, color="yellow", linewidth=2, label="saftest", legend=True,
                        linestyle="dashed")
    pctChangeTable['yield_2'].plot(figsize=figSize, grid=True, color="green", linewidth=2, label="sharpe", legend=True,
                            linestyle="dashed")
    pctChangeTable['yield_3'].plot(figsize=figSize, grid=True, color="red", linewidth=2, label="max return", legend=True,
                            linestyle="dashed")

    plt.subplots_adjust(bottom=0.4)


    # ------------------ Pritning 3 optimal Protfolios -----------------------
    # Setting max_X, max_Y to act as relative border for window size
    sectorsNames = newPortfolio.getSectorsNames()
    lowWeight = min_variance_port.iloc[0][3:]
    mediumWeight = sharpe_portfolio.iloc[0][3:]
    highWeight = max_returns.iloc[0][3:]
    stocksStrHigh = ""
    stocksStrLow = ""
    stocksStrMedium = ""
    highSectorsWeight = newPortfolio.returnSectorsWeightsAccordingToStocksWeights(highWeight)
    lowSectorsWeight = newPortfolio.returnSectorsWeightsAccordingToStocksWeights(lowWeight)
    mediumSectorsWeight = newPortfolio.returnSectorsWeightsAccordingToStocksWeights(mediumWeight)

    # stocksStrHigh
    for i in range(len(sectorsNames)):
        weight = highSectorsWeight[i] * 100
        stocksStrHigh += sectorsNames[i] + "(" + str("{:.2f}".format(weight)) + "%),\n "
    # stocksStrMedium
    for i in range(len(sectorsNames)):
        weight = mediumSectorsWeight[i] * 100
        stocksStrMedium += sectorsNames[i] + "(" + str("{:.2f}".format(weight)) + "%),\n "
    # stocksStrLow
    for i in range(len(sectorsNames)):
        weight = lowSectorsWeight[i] * 100
        stocksStrLow += sectorsNames[i] + "(" + str("{:.2f}".format(weight)) + "%),\n "

    with pd.option_context("display.float_format", "%{:,.2f}".format):
        plt.figtext(
            0.2,
            0.15,
            "Max returns Porfolio: \n"
            + "Annual returns: " + str(round(max_returns.iloc[0][0], 2)) + "%\n"
            + "Annual volatility: " + str(round(max_returns.iloc[0][1], 2)) + "%\n"
            + "Annual max loss: " + str(round(max_returns.iloc[0][0] - 1.65 * max_returns.iloc[0][1], 2)) + "%\n"
            + "Annual sharpe Ratio: " + str(round(max_returns.iloc[0][2], 2)) + "\n"
            + stocksStrHigh,
            bbox=dict(facecolor="red", alpha=0.5),
            fontsize=11,
            style="oblique",
            ha="center",
            va="center",
            fontname="Arial",
            wrap=True,
        )
        plt.figtext(
            0.45,
            0.15,
            "Safest Portfolio: \n"
            + "Annual returns: " + str(round(min_variance_port.iloc[0][0], 2)) + "%\n"
            + "Annual volatility: " + str(round(min_variance_port.iloc[0][1], 2)) + "%\n"
            + "Annual max loss: " + str(round(min_variance_port.iloc[0][0] - 1.65 * min_variance_port.iloc[0][1], 2)) + "%\n"
            + "Annual sharpe Ratio: " + str(round(min_variance_port.iloc[0][2], 2)) + "\n"
            + stocksStrLow,
            bbox=dict(facecolor="yellow", alpha=0.5),
            fontsize=11,
            style="oblique",
            ha="center",
            va="center",
            fontname="Arial",
            wrap=True,
        )
        plt.figtext(
            0.7,
            0.15,
            "Sharpe  Portfolio: \n"
            + "Annual returns: " + str(round(sharpe_portfolio.iloc[0][0], 2)) + "%\n"
            + "Annual Volatility: " + str(round(sharpe_portfolio.iloc[0][1], 2)) + "%\n"
            + "Annual max loss: " + str(round(sharpe_portfolio.iloc[0][0] - 1.65 * sharpe_portfolio.iloc[0][1], 2)) + "%\n"
            + "Annual sharpe Ratio: " + str(round(sharpe_portfolio.iloc[0][2], 2)) + "\n"
            + stocksStrMedium,
            bbox=dict(facecolor="green", alpha=0.5),
            fontsize=11,
            style="oblique",
            ha="center",
            va="center",
            fontname="Arial",
            wrap=True,
        )
    plt.show()


def plotpriceForcast(stockSymbol, df, isDataGotFromTase):

    if isDataGotFromTase:
        df['closingIndexPrice'].plot()
    else:
        df['Adj Close'].plot()
    df['Forecast'].plot()
    plt.title(stockSymbol + " Stock Price Forecast")
    plt.legend(loc=4)
    plt.xlabel('Date')
    plt.ylabel('Price')
    plt.show()


def plotDistributionOfStocks(stockNames, pctChangeTable):

    plt.subplots(figsize=(8, 8))
    plt.legend()
    plt.xlabel('Return', fontsize=12)
    plt.ylabel('Distribution', fontsize=12)
    for i in range(len(stockNames)):
        sns.distplot(pctChangeTable[stockNames[i]][::30]*100, kde=True, hist=False, rug=False, label=stockNames[i])
    plt.grid(True)
    plt.legend()
    plt.show()


def plotDistributionOfPortfolio(yieldsList):

    labels = ['low risk', 'medium risk', 'high risk']
    plt.subplots(figsize=(8, 8))
    plt.subplots_adjust(bottom=0.4)

    monthlyChanges = [None] * len(yieldsList)# yield changes
    monthlyYields = [None] * len(yieldsList)# monthly yield change
    df_describes = [None] * len(yieldsList)# describe of yield changes
    #monthlyCompoundedReturns = [None] * len(yieldsList) # total change in percent from begining
    #monthlyCompoundedReturns[i] = (1 + monthlyChanges[i]).cumprod() - 1

    for i in range(len(yieldsList)):
        monthlyYields[i] = yieldsList[i].resample('M').first()
        monthlyChanges[i] = monthlyYields[i].pct_change().dropna() * 100
        df_describes[i] = monthlyChanges[i].describe().drop(["count"], axis=0)
        sns.distplot(pd.Series(monthlyChanges[i]), kde=True, hist_kws={'alpha': 0.2}, norm_hist=False, rug=False, label=labels[i])

    plt.xlabel('Monthly Return %', fontsize=12)
    plt.ylabel('Distribution', fontsize=12)
    plt.grid(True)
    plt.legend()
    plt.title("Distribution of Portfolios - by monthly returns")

    with pd.option_context("display.float_format", "%{:,.2f}".format):
        plt.figtext(0.2, 0.15,
            "low risk\n"
            + str(df_describes[0]),
            bbox=dict(facecolor="blue", alpha=0.5), fontsize=11, style="oblique", ha="center", va="center", fontname="Arial", wrap=True)
        plt.figtext(0.45, 0.15,
            "medium risk\n"
            + str(df_describes[1]),
            bbox=dict(facecolor="pink", alpha=0.5), fontsize=11, style="oblique", ha="center", va="center", fontname="Arial",  wrap=True )
        plt.figtext(0.7, 0.15,
            "high risk\n"
            + str(df_describes[2]),
            bbox=dict(facecolor="green", alpha=0.5), fontsize=11, style="oblique", ha="center",  va="center", fontname="Arial", wrap=True )

    plt.show()


def getIsraeliIndexesData(command, israeliIndexes):# get israli indexes data from tase
    """JsonDataList = [0] * len(israeliIndexes)
    if command == "get_past_10_years_history":
        for i in range(len(israeliIndexes)):
            appUrl = getIndexHistory(
                setting.indexEndOfDayHistoryTenYearsUpToday, israeliIndexes[i], 10
            )
            JsonDataList[i] = getSymbolInfo(appUrl)
        # return JsonDataList - TODO - fix , makes unlimited requests"""
    return getIndexesDataManuallyFromJSON(israeliIndexes)
    # TOOD: add more commands

    # return JsonDataList


def createJsonDataFromTase(indexId, nameFile):
    appUrl = getIndexHistory(setting.indexEndOfDayHistoryTenYearsUpToday, indexId, 10)
    jsonData = getSymbolInfo(appUrl)
    createsJsonFile(jsonData, nameFile)


def implement_bb_strategy(data, lower_bb, upper_bb):
    buy_price = []
    sell_price = []
    bb_signal = []
    signal = 0

    for i in range(len(data)):
        if data[i - 1] > lower_bb[i - 1] and data[i] < lower_bb[i]:
            if signal != 1:
                buy_price.append(data[i])
                sell_price.append(np.nan)
                signal = 1
                bb_signal.append(signal)
            else:
                buy_price.append(np.nan)
                sell_price.append(np.nan)
                bb_signal.append(0)
        elif data[i - 1] < upper_bb[i - 1] and data[i] > upper_bb[i]:
            if signal != -1:
                buy_price.append(np.nan)
                sell_price.append(data[i])
                signal = -1
                bb_signal.append(signal)
            else:
                buy_price.append(np.nan)
                sell_price.append(np.nan)
                bb_signal.append(0)
        else:
            buy_price.append(np.nan)
            sell_price.append(np.nan)
            bb_signal.append(0)

    return buy_price, sell_price, bb_signal


def plotbb_strategy_stock(stockName, start="2009-01-01", end="2023-01-01"):
    stockprices = yf.download(stockName, start, end)
    stockprices['MA50'] = stockprices['Adj Close'].rolling(window=50).mean()
    stockprices['50dSTD'] = stockprices['Adj Close'].rolling(window=50).std()
    stockprices['Upper'] = stockprices['MA50'] + (stockprices['50dSTD'] * 2)
    stockprices['Lower'] = stockprices['MA50'] - (stockprices['50dSTD'] * 2)

    stockprices = stockprices.dropna()
    stockprices = stockprices.iloc[51:]

    buy_price, sell_price, bb_signal = implement_bb_strategy(stockprices['Adj Close'], stockprices['Lower'],
                                                             stockprices['Upper'])

    stockprices[['Adj Close', 'Lower', 'Upper']].plot(figsize=(10, 4))
    plt.scatter(stockprices.index, buy_price, marker='^', color='green', label='BUY', s=200)
    plt.scatter(stockprices.index, sell_price, marker='v', color='red', label='SELL', s=200)
    plt.show()

    print("number of green :")
    print(np.count_nonzero(~np.isnan(buy_price)))
    print("number of red :")
    print(np.count_nonzero(~np.isnan(sell_price)))


def plotbb_strategy_Portfolio(pctChangeTable , newPortfolio):
    stockprices = pctChangeTable
    stockprices['Adj Close'] = pctChangeTable['yield_selected']
    stockprices['MA50'] = stockprices['Adj Close'].rolling(window=50).mean()
    stockprices['50dSTD'] = stockprices['Adj Close'].rolling(window=50).std()
    stockprices['Upper'] = stockprices['MA50'] + (stockprices['50dSTD'] * 2)
    stockprices['Lower'] = stockprices['MA50'] - (stockprices['50dSTD'] * 2)

    stockprices = stockprices.dropna()
    stockprices = stockprices.iloc[51:]

    buy_price, sell_price, bb_signal = implement_bb_strategy(stockprices['Adj Close'], stockprices['Lower'],
                                                             stockprices['Upper'])

    stockprices[['Adj Close', 'Lower', 'Upper']].plot(figsize=(10, 4))
    plt.scatter(stockprices.index, buy_price, marker='^', color='green', label='BUY', s=200)
    plt.scatter(stockprices.index, sell_price, marker='v', color='red', label='SELL', s=200)

    sectors = newPortfolio.getSectors()

    stocksStr = ""
    for i in range(len(sectors)):
        name = sectors[i].getName()
        weight = sectors[i].getWeight() * 100
        stocksStr += name + "(" + str("{:.2f}".format(weight)) + "%),\n "

    with pd.option_context("display.float_format", "%{:,.2f}".format):
        plt.figtext(
            0.45,
            0.15,
            "your Portfolio: \n"
            + "Returns: " + str(round(newPortfolio.getAnnualReturns(), 2)) + "%\n"
            + "Volatility: " + str(round(newPortfolio.getVolatility(), 2)) + "%\n"
            + "max loss: " + str(round(newPortfolio.getMaxLoss(), 2)) + "%\n"
            + "Sharpe Ratio: " + str(round(newPortfolio.getSharpe(), 2)) + "\n"
            + stocksStr,
            bbox=dict(facecolor="green", alpha=0.5),
            fontsize=11,
            style="oblique",
            ha="center",
            va="center",
            fontname="Arial",
            wrap=True,
        )

    plt.subplots_adjust(bottom=0.4)



    plt.show()

    print("number of green :")
    print(np.count_nonzero(~np.isnan(buy_price)))
    print("number of red :")
    print(np.count_nonzero(~np.isnan(sell_price)))


# Connect to TASE API and get json data from appUrl
def getSymbolInfo(appUrl):
    conn = http.client.HTTPSConnection("openapigw.tase.co.il")
    payload = ""
    headers = {
        "Authorization": "Bearer " + get_tase_access_token(),
        "Accept-Language": "he-IL",
        "Content-Type": "application/json",
    }
    conn.request("GET", appUrl, payload, headers)
    res = conn.getresponse()
    data = res.read()
    # Decode the bytes object to a string
    json_string = data.decode("utf-8")
    json_obj = json.loads(json_string)
    return json_obj


# Auth
def get_base_64_token():
    # key = '7e247414e7047349d83b7b8a427c529c'
    # secret = '7a809c498662c88a0054b767a92f0399'
    token = setting.key + ":" + setting.secret
    base_64_token = base64.b64encode(token.encode("ascii")).decode("ascii")
    return base_64_token


def get_tase_access_token():
    base_64_token = get_base_64_token()
    # tokenUrl = "https://openapigw.tase.co.il/tase/prod/oauth/oauth2/token"
    payload = "grant_type=client_credentials&scope=tase"
    headers = {
        "Authorization": "Basic " + base_64_token,
        "Content-Type": "application/x-www-form-urlencoded",
    }
    response = requests.request("POST", setting.tokenUrl, headers=headers, data=payload)
    return json.loads(response.text)["access_token"]


# BUILD URL FOR REQUEST
def getIndexHistory(appName, indexId, numOfYears):
    today = datetime.datetime.now()
    startyear = today.year - numOfYears
    startmonth = today.month
    startday = today.day
    endyear = today.year
    endmonth = today.month
    endday = today.day
    return getAppUrlWithDateAndIndex(
        appName, startyear, startmonth, startday, endyear, endmonth, endday, indexId
    )


def getAppUrlWithDateAndIndex(
    appName, startYear, startMounth, startDay, endYear, endMonth, endDay, indexName
):
    return (
        getAppUrlWithoutDate(appName)
        + str(indexName)
        + "&fromDate="
        + str(startYear)
        + "-"
        + str(startMounth)
        + "-"
        + str(startDay)
        + "&toDate="
        + str(endYear)
        + "-"
        + str(endMonth)
        + "-"
        + str(endDay)
    )


def getAppUrlWithoutDate(appName):  # /tase/prod/api/v1/short-sales/weekly-balance
    return setting.prefixUrl + "/" + appName


def getfromAndToDate(numOfYears):
    today = datetime.datetime.now()
    startYear = today.year - numOfYears
    startMounth = today.month
    startDay = today.day
    endYear = today.year
    endMonth = today.month
    endDay = today.day
    fromDate = str(startYear) + "-" + str(startMounth) + "-" + str(startDay)
    toDate = str(endYear) + "-" + str(endMonth) + "-" + str(endDay)

    return fromDate, toDate


# Other functions
def getNameByIndexNumber(indexNumber):
    # Load the JSON data from the file
    jsonData = getJsonData("DB/indicesList")
    result = [
        item["indexName"]
        for item in jsonData["indicesList"]["result"]
        if item["indexId"] == indexNumber
    ]
    # makes it from right to left
    name = result[0]
    return name


def getIndexesDataManuallyFromJSON(sybmolIndexs):  # FOR ISRAELI STOCKS
    if type(sybmolIndexs) == int:
        return getJsonData("DB/History" + str(sybmolIndexs))
    else:
        portfolio = [0] * len(sybmolIndexs)
        for i in range(len(sybmolIndexs)):
            portfolio[i] = getJsonData("DB/History" + str(sybmolIndexs[i]))
        return portfolio


def createsJsonFile(json_obj, nameProduct):
    # Open a file in write mode
    parts = nameProduct.split("/")
    last_element = parts[-1]
    with open(
        "DB/"+last_element + ".json", "w"
    ) as f:  # Use the `dump()` function to write the JSON data to the file
        json.dump(json_obj, f)


def getJsonData(name):
    with codecs.open(name + ".json", "r", encoding="utf-8") as file:
        json_data = json.load(file)
    return json_data


def getUserBasicDataFromDB(userName):
    jsonData = getJsonData(setting.usersJsonName)
    userData = jsonData['usersList'][userName]
    return userData['startingInvestmentAmount'], userData['machineLearningOpt'], userData['selectedModel']


def getUserBasicDataFromForm():  # not it from terminal
    amount = getInverstmentAmount()
    machineLearningOpt = getMachineLearningOption()
    modelOption = getModelOption()
    return amount, machineLearningOpt, modelOption


def getNumOfUsersInDB():
    jsonData = getJsonData(setting.usersJsonName)
    return len(jsonData['usersList'])


def getName():
    print("enter name")
    name = input()
    return name


def getInverstmentAmount():
    print("enter amount of money to invest")
    amount = int(input())
    while amount < 1:
        print("enter amount of money to invest")
        amount = int(input())
    return amount


def getMachineLearningOption():
    print("Interested in using machine learning? 0-no, 1-yes")
    machineLearningOpt = int(input())
    while machineLearningOpt != 0 and machineLearningOpt != 1:
        print("Please enter 0 or 1")
        machineLearningOpt = int(input())
    return machineLearningOpt

def getNumOfYearsHistory():
    print("enter number of years for history")
    numOfYears = int(input())
    while numOfYears < 1:
        print("enter number of years for history")
        numOfYears = int(input())
    return numOfYears

def getModelOption():
    print("choose model: 1 - markovich, 2 - gini\n")
    modelOption = int(input())
    while modelOption != 1 and modelOption != 2:
        print("Please enter 1 or 2")
        modelOption = int(input())
    return modelOption


def getTypeOFindexes():
    print("do you want to include israel indexes? 0-no, 1-yes")
    israeliIndexesChoice = int(input())
    while israeliIndexesChoice != 0 and israeliIndexesChoice != 1:
        print("Please enter 0 or 1")
        israeliIndexesChoice = int(input())

    print("do you want to include usa indexes? 0-no, 1-yes")
    usaIndexesChoice = int(input())
    while usaIndexesChoice != 0 and usaIndexesChoice != 1:
        print("Please enter 0 or 1")
        usaIndexesChoice = int(input())

    return israeliIndexesChoice, usaIndexesChoice


def convertIsraeliIndexToName(IsraliIndexes):
    hebrew_pattern = r"[\u0590-\u05FF\s]+"
    stocksNames = {}
    for i, index in enumerate(IsraliIndexes):
        text = getNameByIndexNumber(index)
        hebrew_parts = re.findall(
            hebrew_pattern, text
        )  # find all the Hebrew parts in the text
        for hebrew_part in hebrew_parts:
            hebrew_part_reversed = "".join(
                reversed(hebrew_part)
            )  # reverse the order of the Hebrew characters in the part
            text = text.replace(
                hebrew_part, hebrew_part_reversed
            )  # replace the original part with the reversed part in the text
        stocksNames[i] = text
    return stocksNames.values()


def findUserInList(userName, usersList):
    for user in usersList:
        if user.getUserName() == userName:
            return user
    return None


def convertUsaIndexToName(UsaIndexes):
    UsaIndexesNames = {}
    for i, index in enumerate(UsaIndexes):
        ticker = yf.Ticker(index)
        UsaIndexesNames[i] = ticker.info["longName"]

    return UsaIndexesNames.values()


def getDataFromForm(pctChangeTable, ThreePortfoliosList, newPortfolio, weighted_low, weighted_medium, weighted_high): #TODO - get from internet

    count = 0
    investment = newPortfolio.getInvestmentAmount()
    pctChangeTable["weighted_sum_1"] = weighted_low
    pctChangeTable["weighted_sum_2"] = weighted_medium
    pctChangeTable["weighted_sum_3"] = weighted_high
    pctChangeTable["yield_1"] = weighted_low
    pctChangeTable["yield_2"] = weighted_medium
    pctChangeTable["yield_3"] = weighted_high
    yield_low = makesYieldColumn(pctChangeTable["yield_1"], weighted_low, investment)
    yield_medium = makesYieldColumn(pctChangeTable["yield_2"], weighted_medium, investment)
    yield_high = makesYieldColumn(pctChangeTable["yield_3"], weighted_high, investment)

    #question 1
    print("for how many years do you want to invest?\n")
    print("0-1 - 1\n""1-3 - 2\n""3-100 - 3\n")

    answer = int(input())
    validAnswerInput(answer)
    count += answer

    #question 2
    print("Which distribution do you prefer?\nlow risk - 1, medium risk - 2, high risk - 3 ?\n")
    yieldsList = [yield_low, yield_medium, yield_high]
    plotDistributionOfPortfolio(yieldsList)


    answer = int(input())
    validAnswerInput(answer)
    count += answer

    #question 3
    print("Which graph do you prefer?\nsaftest - 1, sharpe - 2, max return - 3 ?\n")
    plotThreePortfoliosGraph(ThreePortfoliosList, newPortfolio, pctChangeTable)

    answer = int(input())
    validAnswerInput(answer)
    count += answer

    return getLevelOfRiskByForm(count)


def validAnswerInput(answer):
    while answer < 1 or answer > 3:
        print("Please enter 1,2 or 3")
        answer = int(input())


def getLevelOfRiskByForm(count):
    if count <= 4:
        return 1
    elif count <= 7:
        return 2
    else:
        return 3


def scanGoodStocks():
    # Define the parameters for the scanner
    min_avg_volume = 1000000  # minimum average daily volume
    min_rsi = 50  # minimum RSI value
    min_price = 0  # minimum price (in dollars)
    max_price = 1000  # maximum price (in dollars)

    # Download the list of all tickers from Yahoo Finance
    tickers = yf.Tickers("")

    # Create an empty DataFrame to store the results
    results = pd.DataFrame(columns=["Ticker", "Price", "50-Day MA", "200-Day MA", "52-Week High", "RSI", "Avg Volume"])

    # Loop through the tickers and scan for the best stocks
    for ticker in tickers.tickers:
        try:
            # Download the historical prices for the stock
            history = ticker.history(period="max")

            # Compute the 50-day and 200-day moving averages
            ma50 = ta.trend.SMAIndicator(history["Close"], window=50).sma_indicator()
            ma200 = ta.trend.SMAIndicator(history["Close"], window=200).sma_indicator()

            # Check if the stock is in an uptrend
            if ma50.iloc[-1] > ma200.iloc[-1]:
                # Compute the 52-week high
                high52 = history["High"].rolling(window=252).max().iloc[-1]

                # Check if the stock has broken out to a new high
                if history["Close"].iloc[-1] > high52:
                    # Compute the RSI
                    rsi = ta.momentum.RSIIndicator(history["Close"]).rsi()

                    # Check if the RSI is above the minimum value
                    if rsi.iloc[-1] > min_rsi:
                        # Compute the average daily volume
                        avg_volume = history["Volume"].rolling(window=20).mean().iloc[-1]

                        # Check if the average daily volume is above the minimum value
                        if avg_volume > min_avg_volume:
                            # Check if the price is within the specified range
                            price = history["Close"].iloc[-1]
                            if min_price <= price <= max_price:
                                # Add the result to the DataFrame
                                results = results.append({"Ticker": ticker.ticker, "Price": price,
                                                          "50-Day MA": ma50.iloc[-1], "200-Day MA": ma200.iloc[-1],
                                                          "52-Week High": high52, "RSI": rsi.iloc[-1],
                                                          "Avg Volume": avg_volume}, ignore_index=True)
        except:
            pass

    # Sort the results by RSI in descending order
    results = results.sort_values(by="RSI", ascending=False)
    # Print the top 10 stocks
    print(results.head(10))


def mainMenu():
    # operations- TODO- operates from the site
    print("Welcome to the stock market simulator")
    print("Please select one of the following options:")
    print("1. FORM - for new user")
    print("2. Refresh user data")
    print("3. Plot user's portfolio data")
    print("4. operations for experts:")
    print("5. Exit")

def expertMenu():
    print("Please select one of the following options:")
    print("1. Forcast specific stock")
    print("2. Plot specific stock")
    print("3. Add new history of data's index from tase(json)")
    print("4. makes scanner and find stocks with good result")
    print("5. Exit")




def selectedMenuOptValid(selectedMenuOpt, fromRange, toRange):
    while selectedMenuOpt < fromRange or selectedMenuOpt > toRange:
        print("Please enter 1-8")
        selectedMenuOpt = int(input())
    return selectedMenuOpt
